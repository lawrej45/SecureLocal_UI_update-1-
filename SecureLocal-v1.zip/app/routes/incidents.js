const express=require('express');
const db=require('../../db/database');
const {requireAuth,requireRole,requireRecentMfa,requireAdminMfa}=require('../middleware/auth');
const {audit}=require('../security');
const router=express.Router();
router.get('/report',requireAuth,(req,res)=>res.render('incident-report',{user:req.session.user,error:null}));
router.post('/report',requireAuth,(req,res)=>{
  const category=String(req.body.category||'').trim(); const description=String(req.body.description||'').trim(); const severity=req.body.severity;
  if(!['Account security','Suspicious activity','Privacy concern','System issue','Other'].includes(category)||description.length<10||description.length>2000||!['Low','Medium','High','Critical'].includes(severity)) return res.status(400).render('incident-report',{user:req.session.user,error:'Complete the form. Description must be 10–2000 characters.'});
  const result=db.prepare('INSERT INTO incidents (reporter_id,category,description,severity) VALUES (?,?,?,?)').run(req.session.user.id,category,description,severity);
  audit(req.session.user.id,'INCIDENT_REPORTED',`Incident #${result.lastInsertRowid} submitted (${severity}).`,req); res.redirect('/incidents');
});
router.get('/',requireAuth,requireAdminMfa,(req,res)=>{
  const canReview=req.session.user.role==='Admin';
  if(canReview) audit(req.session.user.id,'ADMIN_INCIDENTS_VIEWED','Admin viewed incident records.',req);
  const incidents=canReview?db.prepare('SELECT i.*,u.username FROM incidents i JOIN users u ON u.id=i.reporter_id ORDER BY i.id DESC').all():db.prepare('SELECT * FROM incidents WHERE reporter_id=? ORDER BY id DESC').all(req.session.user.id);
  res.render('incidents',{user:req.session.user,incidents,canReview});
});
router.post('/:id/status',requireAuth,requireRole('Admin'),requireRecentMfa,(req,res)=>{
  const status=req.body.status; if(!['Open','Investigating','Resolved','Closed'].includes(status)) return res.status(400).send('Invalid incident status.');
  const result=db.prepare('UPDATE incidents SET status=? WHERE id=?').run(status,Number(req.params.id));
  if(result.changes) audit(req.session.user.id,'INCIDENT_STATUS_CHANGED',`Incident #${req.params.id} changed to ${status}.`,req);
  res.redirect('/incidents');
});
module.exports=router;
